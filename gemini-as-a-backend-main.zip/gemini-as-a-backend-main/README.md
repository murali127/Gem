# Gemini as a Backend
A sample Flask App to demonstrate usage of Google's Gemini as a replaced to backends.